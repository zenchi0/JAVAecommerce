/*
    Document   : DAOConnection.java
    Author     : Steve Gubenia
    Class      : CMIS 440
    Professor  : Gubanov
    Project    : Final Project E-commerce website

    This is the database connection class java file.
*/
package com.util;

import java.sql.*;

public  class DAOConnection {
// declare variables    
static Connection conn;
static String driverName = null;
static String serverName = null;
static String serverPort = null;
static String sid = null;
static String url = null;
static String username = null;
static String password = null;

 
   public static Connection sqlconnection(){
       try{
           //connect to oracle database
          driverName = "oracle.jdbc.driver.OracleDriver";
            Class.forName(driverName);
            serverName = "zenchi";
            serverPort = "1521";
            sid = "XE";
            url = "jdbc:oracle:thin:@" + serverName + ":" + serverPort + ":" + sid;
            username = "gubenia1";
            password = "wordpass1";
            conn = DriverManager.getConnection(url, username,password);
            System.out.println("Successfully connected to the database !");
            //catch exceptions
        } catch (ClassNotFoundException e) {
            System.out.println("Could not find the database driver" + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Could not connect to the database" + e.getMessage());
        }
        return conn;
    }
    
}

