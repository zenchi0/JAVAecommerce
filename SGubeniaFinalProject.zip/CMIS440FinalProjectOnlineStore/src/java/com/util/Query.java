/*
    Document   : Query.java
    Author     : Steve Gubenia
    Class      : CMIS 440
    Professor  : Gubanov
    Project    : Final Project E-commerce website

    This is the database query class
*/
package com.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.HashMap;
import java.util.logging.Logger;

public class Query {

    static Connection con;
    static Statement stmt;
    static PreparedStatement ps;
    static String query;
    static ResultSet rs;
    static ArrayList list = new ArrayList();
    static ProductDetails productdetails = new ProductDetails(); 
    static HashMap map = new HashMap();
    static ArrayList productname = new ArrayList();
    static ArrayList brandname = new ArrayList();
    static ArrayList productdescription = new ArrayList();
    static ArrayList productprice = new ArrayList();
    static ArrayList producturl = new ArrayList();
    static ArrayList productid  = new ArrayList();

    public static HashMap get_product_info(String classifier_name) {
        try {
            con = DAOConnection.sqlconnection();
            if (classifier_name.equalsIgnoreCase("books")) {
                query = "select book_url,book_name,author_name,book_description,book_price,book_id from books";
            }
            if (classifier_name.equalsIgnoreCase("electronics")) {
                query = "select brand_url,brand_name,store_name,brand_description,brand_price,electronics_id from electronics";
            }
            if (classifier_name.equalsIgnoreCase("goods")) {
                query = "select goods_url,goods_brand,goods_name,goods_description,goods_price,goods_id from goods";
            }
            ps = con.prepareStatement(query);
            rs = ps.executeQuery(query);
            productname = new ArrayList();
            brandname = new ArrayList();
            productdescription = new ArrayList();
            productprice = new ArrayList();
            producturl = new ArrayList();
            productid = new ArrayList();

            while (rs != null && rs.next()) {
                producturl.add(rs.getString(1));
                productname.add(rs.getString(2));       // using 4 objects to get 6 different values from a db         
                brandname.add(rs.getString(3));         // and storing it in a list
                productdescription.add(rs.getString(4));
                productprice.add(rs.getString(5));
                productid.add(rs.getString(6));
            }
            // debugging statements printed in the glassfish output console
            productdetails.setProduct_name(productname);
            System.out.println("Getting product name from get_product_info = " + productdetails.getProduct_name());
            productdetails.setProduct_brand(brandname);
            System.out.println("Getting product brand from get_product_info = " + productdetails.getProduct_brand());
            productdetails.setProduct_description(productdescription);
            System.out.println("Getting product description from get_product_info = " + productdetails.getProduct_description());
            productdetails.setProduct_price(productprice);
            System.out.println("Getting product price from get_product_info = " + productdetails.getProduct_price());
            productdetails.setProduct_price(producturl);
            System.out.println("Getting product url from get_product_info = " + productdetails.getProduct_url());
            productdetails.setProduct_id(productid);
            System.out.println("Getting product id from get_product_info = " + productdetails.getProduct_id());


            map.put("producturl", producturl);
            map.put("productname", productname);      //list values are stored in a map so, that, we could  
            map.put("brandname", brandname);          //return the map object there by all the 6 list objects are passed. 
            map.put("productdescription", productdescription);
            map.put("productprice", productprice);
            map.put("productid",productid);
            
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                    System.out.println("Conntection Terminated after retrieving the product information");
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return map;
    }

    public ProductDetails getProductDetails() {
        productname = null;
        productdetails.setProduct_name(productname);
        brandname = null;
        productdetails.setProduct_brand(brandname);
        productdescription = null;
        productdetails.setProduct_description(productdescription);
        productprice = null;
        productdetails.setProduct_price(productprice);
        return productdetails;
    }
    static void clearSession() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
    //basic insert data method, not used, the real method follow underneath
    public void insert_data(String classifier_name) {
        try {
            con = DAOConnection.sqlconnection();
            if (classifier_name.equals("books")) {
                String book_id = null;
                String book_name = null;
                String author_name = null;
                String book_desc = null;
                String price = null;
                String url = null;
                 query = "insert into books values books_id = ' " + book_id + "' book_name = '" + book_name + 
                      "' author_name = '" + author_name + "' book_description = '" + book_desc + "' book_price = '" + price + "' book_url = '" + url +"'";
                query = "insert into employee_details values (3,'Vishnu')";
            }
            if (classifier_name.equals("electronics")) {
                query = "select brand_name,store_name,brand_description,brand_price, brand_url from electronics";
            }
            if (classifier_name.equals("goods")) {
                query = "select goods_brand,goods_name,goods_description,gooods_price, goods_url from goods";
            }
            ps = con.prepareStatement(query);
            rs = ps.executeQuery(query);
            productname = new ArrayList();
            brandname = new ArrayList();
            productdescription = new ArrayList();
            productprice = new ArrayList();

            while (rs != null && rs.next()) {
                productname.add(rs.getString(1));       // using 4 objects to get 4 different values from a db         
                brandname.add(rs.getString(2));         // and storing it in a list
                productdescription.add(rs.getString(3));
                productprice.add(rs.getString(4));
            }
            productdetails.setProduct_name(productname);
            System.out.println("Getting product name from get_product_info = " + productdetails.getProduct_name());
            productdetails.setProduct_brand(brandname);
            System.out.println("Getting product brand from get_product_info = " + productdetails.getProduct_brand());
            productdetails.setProduct_description(productdescription);
            System.out.println("Getting product description from get_product_info = " + productdetails.getProduct_description());
            productdetails.setProduct_price(productprice);
            System.out.println("Getting product price from get_product_info = " + productdetails.getProduct_price());


            map.put("productname", productname);      //list values are stored in a map so, that, we could  
            map.put("brandname", brandname);          //return the map object there by all the 5 list objects are passed. 
            map.put("productdescription", productdescription);
            map.put("productprice", productprice);
            map.put("producturl", producturl);
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                    System.out.println("Conntection Terminated after retrieving the product information");
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    
// the method used by the admin to insert data into the database
    public String insert_data_into_db(String classifier_name, String admin_product_id, String admin_product_name, String admin_product_author_store_name, String admin_product_description, String admin_product_price, String admin_product_url ) {
        //debugging statements for console output
        String insertion_result = "";
        System.out.println("admin_product_id = " + admin_product_id);
        System.out.println("admin_product_price = " + admin_product_price);
        System.out.println("admin_product_author_store_name = " + admin_product_author_store_name);
        System.out.println("admin_product_description = " + admin_product_description);
        System.out.println("admin_product_name = " + admin_product_name);
        System.out.println("admin_product_url = " + admin_product_url);
        try {
            //connect to database
            con = DAOConnection.sqlconnection();
            //if books insert into books
            if (classifier_name.equals("Books")) {
                query = " insert into books values (?,?,?,?,?,?)";
            } //insert into electronics
            if (classifier_name.equals("Electronics")) {
                query = " insert into electronics values (?,?,?,?,?,?)";
            }//insert into goods
            if (classifier_name.equals("Goods")) {
                query = " insert into goods values (?,?,?,?,?,?)";
            }
            // prepared statement set string values and execute query update
            ps = con.prepareStatement(query);
            ps.setString(1, admin_product_id);
            ps.setString(2, admin_product_name);
            ps.setString(3, admin_product_author_store_name);
            ps.setString(4, admin_product_description);
            ps.setString(5, admin_product_price);
            ps.setString(6, admin_product_url);
            int i = ps.executeUpdate();
            // verify on jsp page if insertion was success or failure
            if (i > 0) {
                System.out.println("Insertion into database done successfully!");
                insertion_result = "success";

            } else {
                System.out.println("Failed to insert into database");
                insertion_result = "failure";
            } // catch exceptions
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                    System.out.println("Conntection Terminated after sucessful/failure insertion into db");
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return insertion_result;
    }

    // delete from database method
    String remove_data(String classifier_name, String admin_radio_selection, String admin_id_or_name) {
        String db_delete_result = "";
        System.out.println("admin_radio_selection = " + admin_radio_selection);
        System.out.println("admin_id_or_name = " + admin_id_or_name);
        System.out.println("classifier_name = " + classifier_name);
        try {
            // connect to database adn create query statements
            con = DAOConnection.sqlconnection();
            stmt = con.createStatement();
            //case for books
            if (classifier_name.equalsIgnoreCase("Books")) {
                if (admin_radio_selection.equals("id")) {
                    query = " DELETE FROM books WHERE books_id = '" + admin_id_or_name + "'";
                } else {
                    query = " DELETE FROM books WHERE book_name = '" + admin_id_or_name + "'";
                }
            }//case for electronics
            if (classifier_name.equalsIgnoreCase("Electronics")) {
                if (admin_radio_selection.equals("id")) {
                    query = " DELETE FROM electronics WHERE electronics_id = '" + admin_id_or_name + "'";
                } else {
                    query = " DELETE FROM electronics WHERE brand_name = '" + admin_id_or_name + "'";
                }
            } // case for goods
            if (classifier_name.equalsIgnoreCase("Goods")) {
                if (admin_radio_selection.equals("id")) {
                    query = " DELETE FROM goods WHERE goods_id = '" + admin_id_or_name + "'";
                } else {
                    query = " DELETE FROM goods WHERE goods_name = '" + admin_id_or_name + "'";
                }
            }
            
            int i = stmt.executeUpdate(query);
            
             // verify on jsp page if deletion success or failure
            if (i > 0) {
                System.out.println("Deleted from database successfully!");
                db_delete_result = "success";

            } else {
                System.out.println("Failed to delete from database");
                db_delete_result = "failure";
            } // catch exceptions
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                    System.out.println("Conntection Terminated after sucessful/failure deletion from db");
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return db_delete_result;
    }
    // update  database method
    String update_data_into_db(String classifier_name, String admin_product_id, String admin_product_name,
                        String admin_product_author_store_name, String admin_product_description, String admin_product_price, String admin_product_url) {
        String db_update_result="";
        try {
            // connect to database and create query statements 
            con = DAOConnection.sqlconnection();
            stmt = con.createStatement();
            // case for books
            if (classifier_name.equals("Books")) {                
                    query = "update books set book_name='"+admin_product_name+"',author_name='"+admin_product_author_store_name+"',book_description='"
                        +admin_product_description+"',book_price='"+admin_product_price+"',book_url='"+admin_product_url+"'where books_id='"+admin_product_id+"'";
            } // case for electronics
            if (classifier_name.equals("Electronics")) {                 
                    query = "update electronics set brand_name='"+admin_product_name+"',store_name='"+admin_product_author_store_name+"',brand_description='"
                        +admin_product_description+"',brand_price='"+admin_product_price+"',brand_url='"+admin_product_url+"'where electronics_id='"+admin_product_id+"'";
            } // case for goods
            if (classifier_name.equals("Goods")) {
                    query = "update goods set goods_brand='"+admin_product_name+"',goods_name='"+admin_product_author_store_name+"',goods_description='"
                        +admin_product_description+"',goods_price='"+admin_product_price+"',goods_url='"+admin_product_url+"'where goods_id='"+admin_product_id+"'";
            } // verify on jsp page if update was success or failure            
            int i = stmt.executeUpdate(query);
            if (i > 0) {
                System.out.println("Updated into database successfully!");
                db_update_result = "success";
            } else {
                System.out.println("Failed to update into database");
                db_update_result = "failure";
            } // catch exceptions
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                    System.out.println("Conntection Terminated after sucessful/failure deletion from db");
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return db_update_result;
    }
}// class query ends here..
