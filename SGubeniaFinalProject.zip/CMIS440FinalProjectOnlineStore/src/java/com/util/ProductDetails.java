/*
    Document   : Product.java
    Author     : Steve Gubenia
    Class      : CMIS 440
    Professor  : Gubanov
    Project    : Final Project E-commerce website

    This is the java class to get all the details about a specific product.
*/
package com.util;

import java.util.List;
import javax.annotation.ManagedBean;


@ManagedBean
public class ProductDetails {  // class name
    //declare variables
    private List<String> product_name;     //storing name in a list array. 
    private List<String> product_description; //storing description in a list array.
    private List<String> product_price; //storing price in a list array.
    private List<String> product_brand; //storing brand name in a list array.
    private List<String> product_author; //storing product authro in a list array.
    private List<String> product_url; // storing image url in an list array 
    private List<String> product_id; //storing id in a list array.
    
    
    // getters and setters for all product data
    public void setProduct_name(List<String> product_name) {        
        this.product_name = product_name;        
    }
    
    public List<String> getProduct_name() {
        if(product_name!=null){
            this.product_name=product_name;
            System.out.println("In USER BEAN");
        }
        return product_name;
    }

    public List<String> getProduct_description() {
        
        return product_description;
    }

    public void setProduct_description(List<String> product_description) {
        this.product_description = product_description;
    }

    public List<String> getProduct_price() {
        return product_price;
    }

    public void setProduct_price(List<String> product_price) {
        this.product_price = product_price;
    }

    public List<String> getProduct_brand() {
        return product_brand;
    }

    public void setProduct_brand(List<String> product_brand) {
        this.product_brand = product_brand;
    }


    public List<String> getProduct_author() {
        return product_author;
    }
    
    public void setProduct_author(List<String> product_author) {
        this.product_author = product_author;
    }
    
        public List<String> getProduct_url() {
        return product_url;
    }
    
    public void setProduct_url(List<String> product_url) {
        this.product_url = product_url;
    }
    
    public List<String> getProduct_id() {
        return product_id;
    }
    
    public void setProduct_id(List<String> product_id) {
        this.product_id = product_id;
    }
    
}

