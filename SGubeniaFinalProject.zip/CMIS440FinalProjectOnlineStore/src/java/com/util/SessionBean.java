/*
    Document   : SessionBean.java
    Author     : Steve Gubenia
    Class      : CMIS 440
    Professor  : Gubanov
    Project    : Final Project E-commerce website

    This is the SessionBean java class for storing the username and password
    information for the session.
*/
package com.util;


public class SessionBean {

    private String name;

    public String getName() {
            return name;
    }

    public void setName(String name) {
        System.out.println("Setting the bean name as = " + name);
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    private String password;
}
