/*
    Document   : CartDetails.java
    Author     : Steve Gubenia
    Class      : CMIS 440
    Professor  : Gubanov
    Project    : Final Project E-commerce website

    this is the cart details java class that contains all methods necessary
    to get the details of items placed in the user cart.
*/
package com.util;

import java.util.List;

public class CartDetails {
    
    private List<String> product_name;     //storing name in a list array. 
    private List<String> product_description; // storing description in list array
    private List<String> product_price; // storing price in list array
    private List<String> product_brand; // storing brand in list arrya

    // getters and setters for all list arrays
    
    public List<String> getProduct_name() {
        return product_name;
    }

    public void setProduct_name(List<String> product_name) {
        this.product_name = product_name;
    }

    public List<String> getProduct_description() {
        return product_description;
    }

    public void setProduct_description(List<String> product_description) {
        this.product_description = product_description;
    }

    public List<String> getProduct_price() {
        return product_price;
    }

    public void setProduct_price(List<String> product_price) {
        this.product_price = product_price;
    }

    public List<String> getProduct_brand() {
        return product_brand;
    }

    public void setProduct_brand(List<String> product_brand) {
        this.product_brand = product_brand;
    }
}
