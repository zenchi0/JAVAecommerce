drop table "GUBENIA1".BOOKS;
create table "GUBENIA1".BOOKS
(
	BOOK_ID INT not null constraint BOOK_ID_PK primary key,
	BOOK_NAME VARCHAR2(50) not null,
	AUTHOR_NAME VARCHAR2(50) not null,
	BOOK_DESCRIPTION VARCHAR2(500) not null,
	BOOK_PRICE VARCHAR2(25) not null,
        BOOK_URL VARCHAR2(20) not null
);

INSERT INTO GUBENIA1.books VALUES (1,'Fight Club','Chuck Palahniuk','The two bored men form an underground club with strict rules and fight other men who are fed up with their mundane lives.','10', 'Images/fightclub.png');
INSERT INTO GUBENIA1.books VALUES(2,'The Time Machine','H.G. Wells','The Time Traveller had finally finished work on his time machine, and it rocketed him into the future. When the machine stops, in the year 802,701 AD, he finds himself in a paradisiacal world of small humanoid creatures called Eloi.','15', 'Images/machine.png');
INSERT INTO GUBENIA1.books VALUES(3,'Sherlock Holmes','Arhur Conan Doyle','Adventures of Londons greatest detective','12','Images/sherlock.png');
