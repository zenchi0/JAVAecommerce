drop table "GUBENIA1".GOODS;
create table "GUBENIA1".GOODS
(
	GOODS_ID INT not null constraint GOODS_ID_PK primary key,
	GOODS_BRAND VARCHAR2(50) not null,
	GOODS_NAME VARCHAR2(50) not null,
	GOODS_DESCRIPTION VARCHAR2(500) not null,
	GOODS_PRICE VARCHAR2(20) not null,
        GOODS_URL VARCHAR2(20) not null
        
);

INSERT INTO GUBENIA1.GOODS VALUES (2, 'Iron', 'Oster', 'Press your shirts and pants in a jiffy', '20', 'Images/iron.png');
INSERT INTO GUBENIA1.GOODS VALUES (3, 'Frying Pan', 'Calphalon', 'Nothing sticks to this cookware', '15', 'Images/pan.jpg');
