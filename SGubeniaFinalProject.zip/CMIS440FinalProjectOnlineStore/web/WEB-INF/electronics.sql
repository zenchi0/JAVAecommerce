drop table "GUBENIA1".ELECTRONICS;
create table "GUBENIA1".ELECTRONICS
(
	ELECTRONICS_ID INT not null constraint ELECTRONICS_ID_PK primary key,
	BRAND_NAME VARCHAR2(50) not null,
	STORE_NAME VARCHAR2(50) not null,
	BRAND_DESCRIPTION VARCHAR2(500) not null,
	BRAND_PRICE VARCHAR2(20) not null,
        BRAND_URL VARCHAR2(20) not null
);

INSERT INTO GUBENIA1.electronics VALUES (1,'SonyVaio','Sony','Superfast Processor with Amazing HD touchscreen ','1000', 'Images/sony.png');
INSERT INTO GUBENIA1.electronics VALUES(2,'Galaxy S6','Samsung','Samsungs latest and greates Android smart phone','750','Images/galaxy.jpg');
INSERT INTO GUBENIA1.ELECTRONICS VALUES (3, 'Surface Pro 3', 'Microsoft', 'Windows 8.1 Pro/ 8GB RAM', '2000', 'Images/surface.jpeg');
