create table "GUBENIA1".LOGIN_DETAILS
(
	LOGIN_ID DECIMAL(22) not null,
	USERNAME VARCHAR2(50) not null,
	PASSWORD VARCHAR2(50) not null,
	USERTYPE VARCHAR2(10) not null,
	primary key (LOGIN_ID, USERNAME)
)

INSERT INTO GUBENIA1.login_details VALUES (01,'admin','root','admin');
INSERT INTO GUBENIA1.login_details VALUES(02,'odin','ragnar','admin');
INSERT INTO GUBENIA1.login_details VALUES(03,'xues','guru','admin');
INSERT INTO GUBENIA1.login_details VALUES(04,'userone','password','user');
INSERT INTO GUBENIA1.login_details VALUES(05,'usertwo','wordpass','user');
INSERT INTO GUBENIA1.login_details VALUES(06,'user3','open','user');
INSERT INTO GUBENIA1.login_details VALUES(07,'thatguy','enter','user');